import Methods.Methods;

import static Methods.Methods.paper;
import static Methods.Methods.scissors;

public class Main {

    public static void main(String[] args) throws InterruptedException {
        Runnable runnable = new Runnable() {
            @Override
            public void run() {

                try {
                    Methods.doSun();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }

                try {
                    Methods.doCloud();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        };
        Thread thread1 = new Thread(() -> {
            runnable.run();
        });
        thread1.setName("Егор");
        Thread thread2 = new Thread(() -> {
//            try {
//                Thread.sleep(10);
//            } catch (InterruptedException e) {
//                throw new RuntimeException(e);
            //           }
            runnable.run();
        });
        thread2.setName("Вова");
            thread1.start();
            thread2.start();
    }
}